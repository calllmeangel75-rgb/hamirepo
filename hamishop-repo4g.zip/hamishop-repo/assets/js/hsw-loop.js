/**
 * HamiShop loop widgets — shared behavior.
 *
 * Timers, arrows, lazy tabs and add-to-cart for the three loop widgets.
 * Vanilla JS, no dependencies, delegated events only.
 */
(function () {
	'use strict';

	var doc = document;
	var data = window.hswData || {};
	var FA = '۰۱۲۳۴۵۶۷۸۹';
	var motion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth';

	function each(list, fn) {
		Array.prototype.forEach.call(list || [], fn);
	}

	function fa(value) {
		return String(value).replace(/[0-9]/g, function (d) {
			return FA.charAt(+d);
		});
	}

	function pad(value) {
		return (value < 10 ? '0' : '') + value;
	}

	function roots() {
		return doc.querySelectorAll('.hsw-loop');
	}

	/* ---------- Countdown -------------------------------------------------
	 * One interval for every widget on the page, paused while the tab is
	 * hidden. The first paint comes from PHP, so no dead 00:00:00 flash.
	 */
	var timers = [];
	var ticker = 0;

	function collectTimers() {
		timers = [].slice.call(doc.querySelectorAll('.hsw-loop__timer[data-hsw-end]'));
	}

	/*
	 * The timer never dies on 00:00:00: the widget chooses what happens when the
	 * deadline passes — hide the timer, hide the whole block, or swap in the
	 * editable «ended» note. `data-hsw-done` makes this run once per timer.
	 */
	function finishTimer(el) {
		if (el.getAttribute('data-hsw-done')) {
			return;
		}
		el.setAttribute('data-hsw-done', '1');

		var action = el.getAttribute('data-hsw-end-action') || 'hide_timer';

		if ('hide_block' === action) {
			var root = el.closest('.hsw-loop');
			if (root) {
				root.classList.add('is-ended-hidden');
				root.setAttribute('hidden', 'hidden');
			}
			return;
		}

		if ('ended_note' === action) {
			var text = el.getAttribute('data-hsw-end-text') || '';
			el.classList.add('hsw-loop__timer--ended');
			el.removeAttribute('role');
			el.setAttribute('role', 'status');
			el.innerHTML = (window.hswIcon ? window.hswIcon('timer') : '') + '<span class="hsw-loop__timer-label"></span>';
			var label = el.querySelector('.hsw-loop__timer-label');
			if (label) {
				label.textContent = text;
			}
			return;
		}

		el.hidden = true;
	}

	/*
	 * Server-anchored clock.
	 *
	 * `data-hsw-end` is a UNIX timestamp from the server, but `Date.now()`
	 * belongs to the visitor's device — a laptop five minutes behind showed a
	 * countdown five minutes too long, and a device with a broken clock could
	 * show the deal as already finished. The markup carries the server's own
	 * `time()` in `data-hsw-now`; from that we keep one offset and only measure
	 * elapsed local time, so the countdown follows the server, not the device.
	 */
	var serverSkew = null;
	var localStart = Date.now();

	function nowMs() {
		if (null === serverSkew) {
			var el = timers[0] || doc.querySelector('[data-hsw-now]');
			var serverNow = el ? parseInt(el.getAttribute('data-hsw-now'), 10) : 0;
			serverSkew = serverNow > 0 ? (serverNow * 1000) - localStart : 0;
		}
		return Date.now() + serverSkew;
	}

	function tick() {
		var now = nowMs();
		var alive = 0;

		each(timers, function (el) {
			if (el.hidden || !el.isConnected || el.getAttribute('data-hsw-done')) {
				return;
			}

			var end = (parseInt(el.getAttribute('data-hsw-end'), 10) || 0) * 1000;
			var left = Math.floor((end - now) / 1000);

			if (left <= 0) {
				finishTimer(el);
				return;
			}

			alive++;
			var h = Math.floor(left / 3600);
			var m = Math.floor(left / 60) % 60;
			var s = left % 60;

			each(el.querySelectorAll('[data-hsw-t]'), function (part) {
				var key = part.getAttribute('data-hsw-t');
				part.textContent = fa(pad(key === 'h' ? h : key === 'm' ? m : s));
			});
		});

		if (!alive) {
			stopTicker();
		}

		return alive;
	}

	function startTicker() {
		if (ticker || doc.hidden) {
			return;
		}
		collectTimers();
		if (!timers.length || !tick()) {
			return;
		}
		ticker = window.setInterval(tick, 1000);
	}

	function stopTicker() {
		if (ticker) {
			window.clearInterval(ticker);
			ticker = 0;
		}
	}

	/* ---------- Rail / arrows --------------------------------------------- */
	function railStep(rail) {
		var card = rail.querySelector('.hsw-loop__card, .hsw-loop__lead, .hsw-loop__more');
		var gap = parseFloat(window.getComputedStyle(rail).columnGap || '12') || 12;
		var width = card ? card.getBoundingClientRect().width : 200;
		return (width + gap) * (window.innerWidth >= 768 ? 2 : 1);
	}

	function maxScroll(rail) {
		return Math.max(0, rail.scrollWidth - rail.clientWidth);
	}

	function syncArrows(root) {
		var rails = root.querySelectorAll('[data-hsw-rail]');
		var prev = false;
		var next = false;

		each(rails, function (rail) {
			var max = maxScroll(rail);
			if (max < 2) {
				return;
			}
			var pos = Math.abs(rail.scrollLeft);
			if (pos > 1) {
				prev = true;
			}
			if (pos < max - 1) {
				next = true;
			}
		});

		each(root.querySelectorAll('.hsw-loop__arrow[data-hsw-dir]'), function (button) {
			var dir = parseInt(button.getAttribute('data-hsw-dir'), 10);
			button.disabled = dir < 0 ? !prev : !next;
		});
	}

	function scrollRails(root, dir) {
		var rtl = window.getComputedStyle(root).direction === 'rtl';
		var sign = dir * (rtl ? -1 : 1);

		each(root.querySelectorAll('[data-hsw-rail]'), function (rail) {
			var max = maxScroll(rail);
			if (max < 2) {
				return;
			}
			var target = rail.scrollLeft + sign * railStep(rail);
			if (rtl) {
				target = Math.max(-max, Math.min(0, target));
			} else {
				target = Math.max(0, Math.min(max, target));
			}
			rail.scrollTo({ left: target, behavior: motion });
		});
	}

	function syncFit(root) {
		var value = parseFloat(window.getComputedStyle(root).getPropertyValue('--hsw-loop-cards'));
		if (!isNaN(value)) {
			root.setAttribute('data-hsw-fit', value > 0 ? 'cards' : 'fixed');
		}
	}

	function refresh() {
		each(roots(), function (root) {
			syncFit(root);
			syncArrows(root);
		});
	}

	/* ---------- Lazy tabs -------------------------------------------------- */
	var fragments = {};

	function selectTab(tabs, active) {
		each(tabs.querySelectorAll('.hsw-loop__tab'), function (tab) {
			var on = tab === active;
			tab.classList.toggle('is-active', on);
			tab.setAttribute('aria-selected', on ? 'true' : 'false');
			tab.tabIndex = on ? 0 : -1;
		});
	}

	function loadTab(root, rail, url) {
		if (fragments[url]) {
			rail.innerHTML = fragments[url];
			rail.scrollLeft = 0;
			syncArrows(root);
			return;
		}

		var previous = rail.innerHTML;
		var count = parseInt(root.getAttribute('data-hsw-count'), 10) || 4;
		var card = rail.querySelector('.hsw-loop__card');
		var skeleton = '';

		if (card) {
			rail.style.setProperty('--hsw-loop-skel-h', Math.round(card.getBoundingClientRect().height) + 'px');
		}
		for (var i = 0; i < count; i++) {
			skeleton += '<div class="hsw-loop__skeleton" aria-hidden="true"></div>';
		}

		rail.setAttribute('aria-busy', 'true');
		rail.classList.add('is-loading');
		rail.innerHTML = skeleton;

		function done() {
			rail.removeAttribute('aria-busy');
			rail.classList.remove('is-loading');
			rail.style.removeProperty('--hsw-loop-skel-h');
			syncArrows(root);
		}

		fetch(url, { credentials: 'same-origin', headers: { Accept: 'application/json' } })
			.then(function (response) {
				if (!response.ok) {
					throw new Error('bad response');
				}
				return response.json();
			})
			.then(function (json) {
				if (!json || typeof json.html !== 'string') {
					throw new Error('bad payload');
				}
				fragments[url] = json.html;
				rail.innerHTML = json.html;
				rail.scrollLeft = 0;
			})
			.then(done, function () {
				rail.innerHTML = previous;
				done();
			});
	}

	/* ---------- Add to cart ------------------------------------------------ */
	function added(button, payload) {
		button.classList.remove('is-loading');
		button.classList.add('is-added');
		window.setTimeout(function () {
			button.classList.remove('is-added');
		}, 1800);

		doc.dispatchEvent(new CustomEvent('hsw_added_to_cart', { detail: payload }));

		if (window.HSWFeedback) {
			window.HSWFeedback.addedToCart(payload);
		}
	}

	function addToCart(button) {
		var id = button.getAttribute('data-product_id');
		var card = button.closest('.hsw-loop__card');
		var name = card && card.querySelector('.hsw-loop__name');
		var style = data.feedbackStyle || 'modal';
		var body = 'product_id=' + encodeURIComponent(id) + '&quantity=1';

		button.classList.add('is-loading');

		fetch(data.wcAjax || '/?wc-ajax=add_to_cart', {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
			body: body
		})
			.then(function (response) {
				return response.json();
			})
			.then(function (response) {
				if (!response) {
					throw new Error('empty response');
				}
				if (response.error) {
					if (response.product_url) {
						window.location.href = response.product_url;
						return;
					}
					throw new Error('cart error');
				}

				/*
				 * WooCommerce's own contract: themes and plugins listen for
				 * `added_to_cart` to update the mini-cart, the counter and
				 * analytics. Triggering only `wc_fragment_refresh` left them
				 * stale after an add from a loop card.
				 */
				if (window.jQuery) {
					window.jQuery(doc.body).trigger('added_to_cart', [
						response.fragments || {},
						response.cart_hash || '',
						window.jQuery(button)
					]);
					window.jQuery(doc.body).trigger('wc_fragment_refresh');
				}

				button.classList.remove('is-loading');
				if ('off' === style) {
					button.classList.add('is-added');
					window.setTimeout(function () {
						button.classList.remove('is-added');
					}, 1800);
					doc.dispatchEvent(new CustomEvent('hsw_added_to_cart', { detail: { productId: id } }));
					return;
				}

				added(button, {
					fragments: response.fragments,
					cartUrl: data.cartUrl,
					productName: name ? name.textContent.trim() : '',
					style: 'bar' === style ? 'toast' : style,
					labels: {
						added: data.addedText,
						modalTitle: data.modalTitle,
						viewCart: data.viewCart,
						continue: data.continueText,
						close: data.closeText
					}
				});
			})
			.catch(function () {
				button.classList.remove('is-loading');
				if (window.HSWFeedback) {
					window.HSWFeedback.toast(data.errorText || 'افزودن به سبد خرید ممکن نشد.');
				}
			});
	}

	/* ---------- Events ----------------------------------------------------- */
	doc.addEventListener('click', function (event) {
		var target = event.target;
		if (!target || !target.closest) {
			return;
		}

		var arrow = target.closest('.hsw-loop__arrow[data-hsw-dir]');
		if (arrow) {
			var arrowRoot = arrow.closest('.hsw-loop');
			if (arrowRoot) {
				scrollRails(arrowRoot, parseInt(arrow.getAttribute('data-hsw-dir'), 10) || 1);
			}
			return;
		}

		var tab = target.closest('.hsw-loop__tab[data-hsw-url]');
		if (tab && !tab.classList.contains('is-active')) {
			var tabs = tab.closest('.hsw-loop__tabs');
			var tabRoot = tabs && tabs.closest('.hsw-loop');
			var rail = tabRoot && tabRoot.querySelector('[data-hsw-rail]');
			if (tabs && rail) {
				selectTab(tabs, tab);
				loadTab(tabRoot, rail, tab.getAttribute('data-hsw-url'));
			}
			return;
		}

		var add = target.closest('.hsw-loop__btn[data-product_id]');
		if (add && !add.classList.contains('is-loading')) {
			event.preventDefault();
			addToCart(add);
		}
	});

	doc.addEventListener('keydown', function (event) {
		var tab = event.target.closest && event.target.closest('.hsw-loop__tab');
		if (!tab) {
			return;
		}

		var tabs = tab.closest('.hsw-loop__tabs');
		if (!tabs) {
			return;
		}

		var list = [].slice.call(tabs.querySelectorAll('.hsw-loop__tab'));
		var index = list.indexOf(tab);
		var rtl = window.getComputedStyle(tabs).direction === 'rtl';
		var step = 0;

		if (event.key === 'Home') {
			step = -index;
		} else if (event.key === 'End') {
			step = list.length - 1 - index;
		} else if (event.key === 'ArrowRight') {
			step = rtl ? -1 : 1;
		} else if (event.key === 'ArrowLeft') {
			step = rtl ? 1 : -1;
		}

		if (!step) {
			return;
		}

		event.preventDefault();
		var next = list[(index + step + list.length) % list.length];
		if (next) {
			next.focus();
			next.click();
		}
	});

	doc.addEventListener(
		'scroll',
		function (event) {
			var rail = event.target.closest && event.target.closest('[data-hsw-rail]');
			var root = rail && rail.closest('.hsw-loop');
			if (!root || root._hswRaf) {
				return;
			}
			root._hswRaf = window.requestAnimationFrame(function () {
				root._hswRaf = 0;
				syncArrows(root);
			});
		},
		{ capture: true, passive: true }
	);

	var resizeRaf = 0;
	window.addEventListener(
		'resize',
		function () {
			if (resizeRaf) {
				return;
			}
			resizeRaf = window.requestAnimationFrame(function () {
				resizeRaf = 0;
				refresh();
			});
		},
		{ passive: true }
	);

	doc.addEventListener('visibilitychange', function () {
		if (doc.hidden) {
			stopTicker();
		} else {
			startTicker();
		}
	});

	window.addEventListener('load', refresh);

	function boot() {
		refresh();
		startTicker();
	}

	if (doc.readyState === 'loading') {
		doc.addEventListener('DOMContentLoaded', boot);
	} else {
		boot();
	}
})();
